<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@400;700&display=swap" rel="stylesheet">
<style>
body {
    margin: 0;
    padding: 0;
    height: 100vh;
    font-family: 'Quicksand', sans-serif;
    background: linear-gradient(45deg, #49075e, #a563bf);
    color: white;
    display: flex;
    justify-content: space-around;
    align-items: center;
    overflow-x: hidden;
}

.container {
    width: 100%;
    display: flex;
    justify-content: space-around;
    padding: 20px;
}

.faculty-intro, .relationship-chart {
    width: 45%;
    padding: 20px;
    background: transparent;
    border-radius: 15px;
}

.relationship-chart {
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: center;
}

.person {
    position: relative;
    margin: 20px;
    text-align: center;
}

.person img {
    width: 100px;
    border-radius: 50%;
}

.person-info {
    background-color: rgba(255,255,255,0.8);
    color: #000;
    padding: 10px;
    border-radius: 10px;
}

.line {
    position: absolute;
    width: 2px;
    background-color: #FFF;
}

.line-horizontal {
    width: 200px;
    height: 2px;
    top: 150px;
}


</style>


</head>
<body>
<div class="container">
    <div class="faculty-intro">
        <h2>Business, Economics & Law Faculty</h2>
        <p>The BEL faculty at UQ is committed to nurturing ethical leaders with a global outlook. It offers a wide range of programs and courses, grounded in theory and relevant to industry needs.</p>
    </div>
    
    <div class="relationship-chart">
        <div class="person" style="position: relative;">
            <img src="assets/img/test1.jpg" alt="Dean">
            <div class="person-info">
                <strong>Dean</strong><br>
                Jane Doe<br>
                jane.doe@uq.edu.au
            </div>
        </div>
        <div class="line" style="height: 50px; left: 50%; top: 150px; transform: translateX(-50%);"></div>

        <div class="line line-horizontal" style="left: 50%; transform: translateX(-50%);"></div>
        
        <div class="person" style="position: absolute; left: 20px; top: 200px;">
            <img src="assets/img/test1.jpg" alt="Professor 1">
            <div class="person-info">
                <strong>Professor</strong><br>
                John Smith<br>
                john.smith@uq.edu.au
            </div>
        </div>
        
        <div class="person" style="position: absolute; right: 20px; top: 200px;">
            <img src="assets/img/test1.jpg" alt="Professor 2">
            <div class="person-info">
                <strong>Professor</strong><br>
                Emily Johnson<br>
                emily.johnson@uq.edu.au
            </div>
        </div>
    </div>
</div>
</body>
<script>
    document.addEventListener('DOMContentLoaded', (event) => {
    const persons = document.querySelectorAll('.person');
    const relationshipChart = document.querySelector('.relationship-chart');

    persons.forEach((person, index) => {
        // 设置随机位置
        person.style.top = `${Math.random() * (relationshipChart.offsetHeight - person.offsetHeight)}px`;
        person.style.left = `${Math.random() * (relationshipChart.offsetWidth - person.offsetWidth)}px`;
    });

    connectPersons();

    function connectPersons() {
        persons.forEach((person, index) => {
            if(index < persons.length - 1) {
                // 创建一个线条元素
                const line = document.createElement('div');
                line.className = 'line';

                // 获取当前人物和下一个人物的位置和尺寸
                const rect1 = person.getBoundingClientRect();
                const rect2 = persons[index + 1].getBoundingClientRect();
                
                // 获取关系图的边界以确定线的相对位置
                const relationshipChartRect = relationshipChart.getBoundingClientRect();

                // 设置线条的位置和尺寸来连接这两个人物
                line.style.top = `${(rect1.top + rect1.bottom) / 2 - relationshipChartRect.top}px`;
                line.style.left = `${(rect1.left + rect1.right) / 2 - relationshipChartRect.left}px`;
                line.style.width = `${Math.sqrt(Math.pow(rect2.left - rect1.left, 2) + Math.pow(rect2.top - rect1.top, 2))}px`;
                line.style.transform = `rotate(${Math.atan2(rect2.top - rect1.top, rect2.left - rect1.left)}rad)`;

                // 添加线条到关系图
                relationshipChart.appendChild(line);
            }
        });
    }
});

</script>
</html>
