<!DOCTYPE html>
<html>
<head>
    <title>Login and Register</title>
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body, html {
            margin: 0;
            padding: 0;
            height: 100%;
            font-family: 'Quicksand', sans-serif;
        }
        .container {
            display: flex;
            flex-direction: row;
            height: 100vh;
            background: linear-gradient(45deg, #49075e, #a563bf);
            color: white;
        }
        .box {
            flex: 1;
            padding: 50px;
            text-align: center;
        }
        .header {
            font-size: 3rem;
            margin-bottom: 20px;
        }
        input {
            padding: 20px;
            margin: 20px;
            font-size: 1.2rem;
            border: none;
            border-radius: 10px;
            width: 40%;
        }
        .submit-button {
            background: white;
            color: #49075e;
            border: none;
            padding: 20px;
            margin: 20px;
            font-size: 1.2rem;
            text-transform: uppercase;
            font-weight: bold;
            border-radius: 10px;
            cursor: pointer;
            transition: background-color 0.3s ease, color 0.3s ease;
            width: 40%;
        }
        .submit-button:hover {
            background: #a563bf;
            color: white;
        }
        .register-button {
            color: white;
            font-size: 1rem;
            font-weight: bold;
        }
        
    </style>
</head>
<body>
    <div class="container">
        <div class="box">
            <div class="header">Login</div>
            <?php echo form_open(base_url().'login/check_login'); ?>
                <input type="text" name="username" placeholder="Username" /><br />
                <input type="password" name="password" placeholder="Password" /><br />
                <input type="submit" value="Login" class="submit-button" />
            </form>
            <?php echo form_close(); ?>
            <?php if (isset($error)): ?>
                <p style="color: red;"><?php echo $error; ?></p>
            <?php endif; ?>

            <a href="<?php echo base_url(); ?>register" class="register-button">Don't have account? Join Us Now!</a>
        </div>
    </div>
</body>
</html>
