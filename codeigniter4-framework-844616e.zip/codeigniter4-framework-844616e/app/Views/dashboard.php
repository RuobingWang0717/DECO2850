<!DOCTYPE html>
<html>
<head>
    <title>User Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body, html {
            margin: 0;
            padding: 0;
            height: 100%;
            font-family: 'Quicksand', sans-serif;
            overflow-x: hidden;
        }
        .container {
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            background: linear-gradient(45deg, #49075e, #a563bf);
            color: white;
            min-height: 100vh;
        }
        .header {
            font-size: 3rem;
            margin-bottom: 20px;
            animation: fadeInDown 1s;
        }
        .profile-section, .details-section {
            width: 50%;
            margin-bottom: 20px;
            border: 2px solid #FFF;
            padding: 20px;
            border-radius: 15px;
            transition: transform 0.3s;
        }
        .profile-section:hover, .details-section:hover {
            transform: scale(1.02);
        }
        .profile-section img {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            margin-bottom: 20px;
            transition: transform 0.3s;
        }
        .profile-section img:hover {
            transform: rotate(360deg);
        }
        .profile-section h2, .details-section h2 {
            font-size: 2rem;
            margin-bottom: 10px;
            animation: fadeIn 1s;
        }
        .profile-section p, .details-section p, .details-section li {
            font-size: 1.2rem;
            animation: fadeIn 1.5s;
        }
        .details-section ul {
            list-style-type: none;
            padding: 0;
        }
        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }
        @keyframes fadeInDown {
            from {
                opacity: 0;
                transform: translateY(-50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        .skills-list {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        .skill-item {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .skill-item span {
            width: 100px;
        }
        .progress-bar {
            width: 100%;
            background-color: #eee;
            border-radius: 5px;
            overflow: hidden;
        }
        .progress-bar-inner {
            height: 10px;
            background-color: #a563bf;
            width: 0;
            transition: width 1s;
        }
 
    </style>
</head>
<body>
    <div class="container">
        <div class="header">User Dashboard</div>

        <div class="profile-section">
            <img src="assets/img/test1.jpg" alt="User Photo">
            <h2>John Doe</h2>
            <p>Email: john.doe@example.com</p>
            <p>Phone: 123-456-7890</p>
        </div>

        <div class="details-section">
            <h2>About John</h2>
            <p>Passionate developer with a knack for creating intuitive UI/UX designs. A team player who brings creativity and a positive approach to problem-solving.</p>
        </div>

        <div class="details-section">
            <h2>Hobbies</h2>
            <ul>
                <li>Photography</li>
                <li>Cycling</li>
                <li>Guitar</li>
            </ul>
        </div>

        <div class="details-section">
            <h2>Skills</h2>
            <div class="skills-list">
                <div class="skill-item">
                    <span>HTML & CSS</span>
                    <div class="progress-bar">
                        <div class="progress-bar-inner" style="width: 90%;"></div>
                </div>
            </div>
            <div class="skill-item">
                <span>JavaScript</span>
                <div class="progress-bar">
                    <div class="progress-bar-inner" style="width: 80%;"></div>
                </div>
            </div>
            <div class="skill-item">
                <span>Python</span>
                <div class="progress-bar">
                    <div class="progress-bar-inner" style="width: 75%;"></div>
                </div>
            </div>
        </div>
    </div>

        <div class="details-section">
            <h2>Current Projects</h2>
            <ul>
                <li>Corporate Website Redesign</li>
                <li>Mobile App Development</li>
            </ul>
        </div>
    </div>
</body>
</html>
