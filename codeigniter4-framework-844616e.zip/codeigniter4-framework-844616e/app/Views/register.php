<!DOCTYPE html>
<html>
<head>
    <title>Login and Register</title>
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body, html {
            margin: 0;
            padding: 0;
            height: 100%;
            font-family: 'Quicksand', sans-serif;
        }
        .container {
            display: flex;
            flex-direction: row;
            height: 100vh;
            background: linear-gradient(45deg, #49075e, #a563bf);
            color: white;
        }
        .box {
            flex: 1;
            padding: 50px;
            text-align: center;
        }
        .header {
            font-size: 3rem;
            margin-bottom: 20px;
        }
        input {
            padding: 20px;
            margin: 20px;
            font-size: 1.2rem;
            border: none;
            border-radius: 10px;
            width: 40%;
        }
        .submit-button {
            background: white;
            color: #49075e;
            border: none;
            padding: 20px;
            margin: 20px;
            font-size: 1.2rem;
            text-transform: uppercase;
            font-weight: bold;
            border-radius: 10px;
            cursor: pointer;
            transition: background-color 0.3s ease, color 0.3s ease;
            width: 40%;
        }
        .submit-button:hover {
            background: #a563bf;
            color: white;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="box">
            <div class="header">Register</div>
            <form>
                <input type="text" placeholder="Username" /><br />
                <input type="email" placeholder="Email" /><br />
                <input type="password" placeholder="Password" /><br />
                <input type="password" placeholder="Confirm Password" /><br />
                <input type="submit" value="Register" class="submit-button" />
            </form>
        </div>
    </div>
</body>
</html>
