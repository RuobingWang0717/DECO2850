<!DOCTYPE html>
<html>
<head>
    <title>Your Interactive Social Network</title>
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body, html {
            margin: 0;
            padding: 0;
            height: 100%;
            font-family: 'Quicksand', sans-serif;
        }
        .container {
            position: relative;
            height: 100vh;
            background: linear-gradient(45deg, #49075e, #a563bf);
            color: white;
            text-align: center;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
        }
        h1 {
            font-size: 4rem;
            margin-bottom: 20px;
            text-transform: capitalize;
        }
        p {
            font-size: 1.4rem;
        }
        .cta-button {
            display: inline-block;
            margin-top: 20px;
            padding: 15px 30px;
            text-transform: uppercase;
            font-weight: bold;
            background: white;
            color: #49075e;
            border-radius: 50px;
            transition: background-color 0.3s ease, color 0.3s ease;
        }
        .cta-button:hover {
            background: #a563bf;
            color: white;
        }
        .animation-text {
            animation: floatText 3s infinite;
        }
        @keyframes floatText {
            0% {
                transform: translateY(0);
            }
            50% {
                transform: translateY(-20px);
            }
            100% {
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="content">
            <h1 class="animation-text">Welcome!</h1>
            <p>Explore Your Team Like Never Before</p>
            <a href="<?php echo base_url(); ?>login" class="cta-button">Get Started</a>
        </div>
    </div>
</body>
</html>
