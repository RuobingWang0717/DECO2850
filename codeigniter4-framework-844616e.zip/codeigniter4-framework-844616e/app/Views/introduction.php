<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@400;700&display=swap" rel="stylesheet">
<style>
    body {
        margin: 0;
        padding: 0;
        height: 100%;
        font-family: 'Quicksand', sans-serif;
        background: linear-gradient(45deg, #49075e, #a563bf);
        color: white;
        overflow-x: hidden;
    }
    .container-fluid {
        padding: 20px;
        display: flex;
        height: 100vh;
        align-items: center;
        justify-content: center;
        background: transparent;
    }
    .sidebar, .main-content {
        border: 2px solid #FFF;
        border-radius: 15px;
        transition: transform 0.3s;
        padding: 20px;
        animation: fadeIn 1s;
    }
    .sidebar:hover, .main-content:hover {
        transform: scale(1.02);
    }
    .sidebar h2, .main-content h2 {
        font-size: 2rem;
        margin-bottom: 20px;
        text-align: center;
    }
    .sidebar ul, .main-content p {
        font-size: 1.2rem;
    }
    .sidebar ul {
        list-style-type: none;
        padding: 0;
    }
    .sidebar li {
        margin-bottom: 10px;
    }
    .sidebar li a {
        color: white;
        text-decoration: none;
        transition: color 0.3s;
    }
    .sidebar li a:hover {
        color: #a563bf;
    }
    @keyframes fadeIn {
        from {
            opacity: 0;
        }
        to {
            opacity: 1;
        }
    }
</style>
</head>
<body>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-3 sidebar">
            <h2>UQ Faculties</h2>
            <ul>
                <li><a href="<?php echo base_url(); ?>business">Business, Economics & Law</a></li>
                <li><a href="<?php echo base_url(); ?>engineering">Engineering, Architecture & IT</a></li>
                <li><a href="<?php echo base_url(); ?>health">Health & Behavioural Sciences</a></li>
                <!-- Add more faculties as needed -->
            </ul>
        </div>
        <div class="col-md-8 offset-md-1 main-content">
            <h2>Welcome to UQ</h2>
            <p>
                Discover an institution renowned for its leadership in education and innovation. At UQ, we are committed to providing our students with the best possible learning experience through excellence in teaching and research. Join us on a journey of knowledge discovery and personal growth as we work together to shape a better future for all.
            </p>
        </div>
    </div>
</div>

</body>
</html>
