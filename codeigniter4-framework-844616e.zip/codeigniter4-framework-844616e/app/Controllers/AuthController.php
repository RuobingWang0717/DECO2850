<?php namespace App\Controllers;

use App\Models\UserModel;
use CodeIgniter\Controller;
use CodeIgniter\HTTP\IncomingRequest;

class AuthController extends Controller
{
    public function login()
    {
        return view('login');
    }

    public function checklogin()
    {
        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');
        
        $correctUsername = "deco2850";
        $correctPassword = "robin";

        // 检查用户名和密码是否正确
        if ($username === $correctUsername && $password === $correctPassword) {
        // 登录成功，设置会话变量等
            session()->set('isLoggedIn', true);
            return redirect()->to('/dashboard');
        } else {
        // 登录失败，返回错误消息
            return view('login', ['error' => 'Invalid username or password']);
        }
        
        
        //return view('login');
        
    }

    public function register()
    {
        return view('register');
        // // 获取用户输入
        // $username = $this->request->getPost('username');
        // $email = $this->request->getPost('email');
        // $password = $this->request->getPost('password');

        // // 在这里添加注册逻辑（例如，检查用户名是否已存在，密码加密，保存到数据库等）

        // // 假设我们有一个UserModel类，用于与数据库进行交互
        // $userModel = new UserModel();
        // $data = [
        //     'username' => $username,
        //     'email' => $email,
        //     'password' => password_hash($password, PASSWORD_DEFAULT),
        // ];
        // $userModel->insert($data);

        // // 注册成功，重定向到登录页面或其他页面
        // return redirect()->to('/login');
    }
}
