<?php

namespace App\Controllers;

class Introduction extends BaseController
{
    public function index()
    {
        return view('introduction');
    }
}