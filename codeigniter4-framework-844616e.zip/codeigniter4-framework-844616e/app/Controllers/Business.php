<?php

namespace App\Controllers;

class Business extends BaseController
{
    public function index()
    {
        return view('business');
    }
}